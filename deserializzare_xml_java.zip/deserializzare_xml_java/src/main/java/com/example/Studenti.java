package com.example;

public class Studenti {
    private String annoDiNascita;
    private String cognome;
    private String nome;

    public Studenti(){

    }

    public String getAnnoDiNascita() {
        return annoDiNascita;
    }

    public String getCognome() {
        return cognome;
    }

    public String getNome() {
        return nome;
    }

    public void setAnnoDiNascita(String annoDiNascita) {
        this.annoDiNascita = annoDiNascita;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}

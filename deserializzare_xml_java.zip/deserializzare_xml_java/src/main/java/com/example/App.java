package com.example;

import java.io.*;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

/**
 * Hello world!
 *
 */
public class App {
    public static void main( String[] args ) throws IOException{

        File file = new File("./src/main/resources/classe.xml");
        XmlMapper xmlMapper = new XmlMapper();
        
        String xml = inputStreamToString(new FileInputStream(file));
        Root value = xmlMapper.readValue(xml, Root.class);
        
        System.out.println("La classe " + value.getClasse() + " " + value.getSpecializzazione()
        + " si trova nell'aula " + value.getAula() + " ed è composta dai seguenti studenti:\n"
        + value.stampaStudenti());
    }

    public static String inputStreamToString(InputStream is) throws IOException {
        StringBuilder sb = new StringBuilder();
        String line;
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }
        br.close();
        return sb.toString();
    }
}

package com.example;

import java.util.ArrayList;

public class Root {
    private int annoDiInizio;
	private Aula aula;
	private String classe;
	private int numeroFinestre;
	private String specializzazione;
	private ArrayList<Studenti> studenti;

    public Root(){
        
    }

    public int getAnnoDiInizio() {
        return annoDiInizio;
    }

    public Aula getAula() {
        return aula;
    }

    public String getClasse() {
        return classe;
    }

    public int getNumeroFinestre() {
        return numeroFinestre;
    }

    public String getSpecializzazione() {
        return specializzazione;
    }

    public ArrayList<Studenti> getStudenti() {
        return studenti;
    }

    public void setAnnoDiInizio(int annoDiInizio) {
        this.annoDiInizio = annoDiInizio;
    }

    public void setAula(Aula aula) {
        this.aula = aula;
    }

    public void setClasse(String classe) {
        this.classe = classe;
    }

    public void setNumeroFinestre(int numeroFinestre) {
        this.numeroFinestre = numeroFinestre;
    }

    public void setSpecializzazione(String specializzazione) {
        this.specializzazione = specializzazione;
    }

    public void setStudenti(ArrayList<Studenti> studenti) {
        this.studenti = studenti;
    }

    public String stampaStudenti(){
        String stringaStudenti = "";
        for(int i = 0; i < studenti.size(); i++){
            stringaStudenti = stringaStudenti + "Cognome " + studenti.get(i).getCognome() + "\n"
            + "Nome: " + studenti.get(i).getNome() + "\n" + "Anno di nascita: " + studenti.get(i).getAnnoDiNascita()
            + "\n\n";
        }
        return stringaStudenti;
    }
}
